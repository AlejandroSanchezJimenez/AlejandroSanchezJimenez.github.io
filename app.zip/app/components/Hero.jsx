'use client'

import { useEffect, useState } from 'react'

export default function Hero({ onFinish }) {
  const name = 'ASANJIMDEV'
  const [letters, setLetters] = useState(
    name.split('').map((char) => ({ char, visible: false }))
  )
  const [phase, setPhase] = useState('typing') // typing | crossfade

  // Animación de letras desde abajo (50ms por letra)
  useEffect(() => {
    if (phase !== 'typing') return

    letters.forEach((_, i) => {
      setTimeout(() => {
        setLetters((prev) =>
          prev.map((l, index) => (index === i ? { ...l, visible: true } : l))
        )
      }, i * 50)
    })

    const totalTime = letters.length * 50 + 300
    const timer = setTimeout(() => {
      setPhase('crossfade')
    }, totalTime)

    return () => clearTimeout(timer)
  }, [phase, letters])

  // Crossfade: el nombre se desvanece mientras las franjas aparecen
  useEffect(() => {
    if (phase !== 'crossfade') return

    // Controlar opacidad del nombre: se va de 1 a 0 en 500ms
    const nameTimer = setTimeout(() => {
      setLetters((prev) => prev.map((l) => ({ ...l, visible: false })))
    }, 500)

    // Determinar clases completas para las franjas
    const stripeClasses =
      phase === 'crossfade'
        ? 'opacity-1 -translate-x-0 md:translate-x-0'
        : 'opacity-0 -translate-x-full sm:translate-x-[100%] md:translate-x-[120%]'

    // Aplicar clases a todas las franjas después de delay
    const delay = 50
    setTimeout(() => {
      const stripes = document.querySelectorAll('.hero-stripe')
      stripes.forEach((stripe) => {
        stripe.className = stripeClasses
      })
      // Después de 600ms, llamar a onFinish
      const endTimer = setTimeout(() => {
        if (onFinish) onFinish()
      }, 600)
    }, delay)

    return () => {
      clearTimeout(nameTimer)
      clearTimeout(endTimer)
    }
  }, [phase, onFinish])

  // Determinar clase del nombre
  const nameClasses =
    phase === 'crossfade'
      ? 'opacity-0 transition-opacity duration-500 ease-out'
      : 'opacity-100'

  // ClassNames fijos
  const fixedHeroClass =
    'relative text-5xl md:text-7xl font-extrabold text-white flex flex-wrap justify-center'
  const fixedStripeBase =
    'hero-stripe w-1/5 h-full bg-gradient-to-tr from-purple-900 via-indigo-800 to-purple-700 absolute'

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-center items-center">
      {/* Franjas verticales - siempre presentes, clase completa según phase */}
      {[0, 1, 2, 3, 4].map((i) => (
        <div
          key={i}
          className={fixedStripeBase + ' ' + stripeClasses}
          style={{ left: `${i * 20}%` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-500 to-transparent"></div>
        </div>
      ))}

      {/* Nombre - className fijo + opacidad según phase */}
      <h1 className={fixedHeroClass + ' ' + nameClasses}>
        {letters.map((l, i) => (
          <span
            key={i}
            className="inline-block transform transition-transform duration-50"
          >
            {l.char === ' ' ? '\u00A0' : l.char}
          </span>
        ))}
      </h1>
    </div>
  )
}
