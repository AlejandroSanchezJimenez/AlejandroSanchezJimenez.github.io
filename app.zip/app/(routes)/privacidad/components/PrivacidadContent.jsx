'use client'

import { useSearchParams } from 'next/navigation'

// Registro de políticas de privacidad por app.
// Para añadir una nueva app en el futuro, solo añade una entrada aquí.

const PRIVACY_POLICIES = {
  mysyncedlist: {
    nombre: 'MySyncList',
    fechaActualizacion: '3 de septiembre de 2026',

    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <ul className="space-y-5">
            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg  text-sm">
                01
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de cuenta.
                </span>{' '}
                Correo electrónico y, en su caso, nombre de usuario, gestionados
                a través de Firebase Authentication.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                02
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Contenido generado por el usuario.
                </span>{' '}
                Listas, elementos añadidos a las listas, grupos creados y su
                configuración, almacenados en Firebase Firestore.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                03
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos técnicos básicos.
                </span>{' '}
                Identificadores de dispositivo e información de uso necesarios
                para el funcionamiento del servicio.
              </p>
            </li>
          </ul>
        )
      },

      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos recogidos se utilizan exclusivamente para ofrecer la
            funcionalidad de la app: crear y sincronizar listas entre los
            miembros de un grupo, gestionar el acceso a tu cuenta y mostrar el
            historial de consumos.
          </p>
        )
      },

      {
        titulo: 'Con quién compartimos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Utilizamos Firebase (Google) como proveedor de infraestructura para
            autenticación y base de datos. No vendemos ni compartimos tus datos
            con terceros con fines publicitarios.
          </p>
        )
      },

      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Conservamos tus datos mientras mantengas una cuenta activa. Puedes
            solicitar la eliminación de tu cuenta y de los datos asociados en
            cualquier momento contactando con nosotros.
          </p>
        )
      },

      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Puedes solicitar acceso, rectificación o eliminación de tus datos
            personales en cualquier momento escribiendo a
            alejandro.sanjim2000@gmail.com
          </p>
        )
      },

      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política ocasionalmente. Cualquier cambio se
            reflejará en esta misma página con la fecha de actualización
            correspondiente.
          </p>
        )
      }
    ]
  },

  totallystyled: {
    nombre: 'TotallyStyled',
    fechaActualizacion: '3 de septiembre de 2026',

    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <ul className="space-y-5">
            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg  text-sm">
                01
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de cuenta.
                </span>{' '}
                Correo electrónico y, en su caso, nombre de usuario, necesarios
                para iniciar sesión y acceder a la app.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                02
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Contenido generado por el usuario.
                </span>{' '}
                Fotografías de prendas de ropa y accesorios que subas a la app,
                así como las combinaciones de outfits que crees y guardes. Las
                imágenes se almacenan a través de Firebase Storage.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                03
              </div>

              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos técnicos básicos.
                </span>{' '}
                Identificadores de dispositivo e información de uso necesarios
                para el funcionamiento del servicio.
              </p>
            </li>
          </ul>
        )
      },

      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos recogidos se utilizan exclusivamente para ofrecer la
            funcionalidad de la app: gestionar tu cuenta, almacenar las imágenes
            de tus prendas y permitirte crear y guardar combinaciones de
            outfits.
          </p>
        )
      },

      {
        titulo: 'Con quién compartimos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Utilizamos Firebase Storage, proporcionado por Google, como
            proveedor de almacenamiento de las imágenes que subes a la app. No
            vendemos ni compartimos tus datos con terceros con fines
            publicitarios.
          </p>
        )
      },

      {
        titulo: 'Pagos y suscripciones',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Determinadas funcionalidades de TotallyStyled se ofrecen a través
            de suscripciones de pago. El cobro se gestiona íntegramente a
            través de la tienda de aplicaciones desde la que descargaste la
            app (App Store o Google Play), que actúa como responsable del
            proceso de pago. TotallyStyled no recoge, procesa ni almacena
            datos de tarjetas ni ninguna otra información de pago: esa
            información se tratará exclusivamente por la tienda, conforme a su
            propia política de privacidad.
          </p>
        )
      },

      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Conservamos tus datos, incluidas las imágenes subidas, mientras
            mantengas una cuenta activa. Puedes solicitar la eliminación de tu
            cuenta y de los datos asociados en cualquier momento contactando con
            nosotros.
          </p>
        )
      },

      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Puedes solicitar acceso, rectificación o eliminación de tus datos
            personales en cualquier momento escribiendo a
            alejandro.sanjim2000@gmail.com
          </p>
        )
      },

      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política ocasionalmente. Cualquier cambio se
            reflejará en esta misma página con la fecha de actualización
            correspondiente.
          </p>
        )
      }
    ]
  },

  rasearch: {
    nombre: 'RaSearch',
    fechaActualizacion: '7 de septiembre de 2026',
    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <ul className="space-y-5">
            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                01
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos personales.
                </span>{' '}
                RAsearch no requiere que el usuario cree una cuenta ni
                proporciona datos personales para utilizar sus funciones
                principales.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                02
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Información de los jeroglíficos.
                </span>{' '}
                La aplicación utiliza una base de datos de jeroglíficos que
                contiene información como identificadores, representaciones,
                significados, transliteraciones y otros datos relacionados con
                la escritura del Antiguo Egipto.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                03
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos técnicos.
                </span>{' '}
                Podrían procesarse datos técnicos básicos necesarios para el
                funcionamiento de la aplicación y de los servicios utilizados,
                como información relacionada con el dispositivo o la conexión.
              </p>
            </li>
          </ul>
        )
      },
      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos y recursos utilizados por RAsearch se emplean
            exclusivamente para proporcionar las funcionalidades de la
            aplicación, incluyendo la búsqueda, consulta y visualización de
            información sobre jeroglíficos del Antiguo Egipto y la generación de
            documentos PDF.
          </p>
        )
      },
      {
        titulo: 'Servicios de terceros',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            RAsearch utiliza Firebase, proporcionado por Google, como
            infraestructura para determinados servicios de la aplicación,
            incluyendo el almacenamiento y consulta de información. Estos
            servicios pueden procesar información técnica necesaria para su
            funcionamiento de acuerdo con sus propias políticas de privacidad.
            RAsearch no vende ni comparte datos personales con terceros con
            fines publicitarios.
          </p>
        )
      },
      {
        titulo: 'Publicidad y seguimiento',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            RAsearch no vende datos personales y no utiliza los datos del
            usuario para crear perfiles publicitarios. La aplicación no requiere
            el registro de una cuenta para acceder a sus funcionalidades
            principales.
          </p>
        )
      },
      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Al no requerir una cuenta de usuario para sus funcionalidades
            principales, RAsearch no mantiene un perfil personal del usuario.
            Los datos necesarios para el funcionamiento de los servicios
            utilizados por la aplicación se conservan durante el tiempo
            necesario para proporcionar dichos servicios.
          </p>
        )
      },
      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Si consideras que la aplicación puede estar tratando datos
            personales relacionados contigo y deseas ejercer tus derechos de
            acceso, rectificación o eliminación, puedes contactar con nosotros
            escribiendo a{' '}
            <span className="font-medium text-slate-900">
              alejandro.sanjim2000@gmail.com
            </span>
            .
          </p>
        )
      },
      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política de privacidad ocasionalmente para
            reflejar cambios en la aplicación, en los servicios utilizados o en
            los requisitos legales aplicables. Cualquier modificación se
            reflejará en esta misma página indicando la fecha de actualización
            correspondiente.
          </p>
        )
      }
    ]
  },

  crowfall: {
    nombre: 'CrowFall',
    fechaActualizacion: '11 de septiembre de 2026',

    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            CrowFall no recopila ni almacena datos personales de los usuarios.
            La aplicación no requiere crear una cuenta, iniciar sesión ni
            proporcionar ningún tipo de información personal para jugar.
          </p>
        )
      },

      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            CrowFall no recopila datos personales y, por tanto, no utiliza
            información personal de los usuarios. La aplicación está diseñada
            para poder jugar directamente sin necesidad de registrarse o iniciar
            sesión.
          </p>
        )
      },

      {
        titulo: 'Almacenamiento de datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            CrowFall no almacena datos personales en servidores ni mantiene
            cuentas o perfiles de usuario. No existe ningún sistema de registro
            o inicio de sesión asociado a la aplicación.
          </p>
        )
      },

      {
        titulo: 'Servicios de terceros',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            CrowFall no comparte datos personales con terceros. La aplicación no
            utiliza información personal del usuario con fines publicitarios ni
            para crear perfiles.
          </p>
        )
      },

      {
        titulo: 'Publicidad y seguimiento',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            CrowFall no utiliza datos personales para realizar seguimiento de
            los usuarios ni para crear perfiles publicitarios.
          </p>
        )
      },

      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Al no recopilar ni almacenar datos personales, CrowFall no mantiene
            información personal del usuario que deba conservarse o eliminarse.
          </p>
        )
      },

      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Como CrowFall no recopila ni almacena datos personales de los
            usuarios, no existe información personal asociada a una cuenta que
            pueda ser consultada, modificada o eliminada.
          </p>
        )
      },

      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política de privacidad ocasionalmente para
            reflejar cambios en la aplicación o en los requisitos legales
            aplicables. Cualquier modificación se reflejará en esta misma página
            indicando la fecha de actualización correspondiente.
          </p>
        )
      }
    ]
  },

  parkly: {
    nombre: 'Parkly',
    fechaActualizacion: '17 de septiembre de 2026',
    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <ul className="space-y-5">
            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                01
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de cuenta.
                </span>{' '}
                Correo electrónico y la información básica asociada a tu perfil,
                necesarios para crear y gestionar tu cuenta en Parkly.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                02
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de ubicación.
                </span>{' '}
                Parkly puede utilizar la ubicación de tu dispositivo para
                mostrar tu posición en el mapa, ayudarte a encontrar parkings
                para motos cercanos y ofrecer las funcionalidades relacionadas
                con el mapa.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                03
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Contenido generado por el usuario.
                </span>{' '}
                Información sobre parkings para motos que añadas a la
                aplicación, así como los lugares que guardes como favoritos y la
                información relacionada con tus contribuciones a la comunidad.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                04
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de actividad.
                </span>{' '}
                Puntos y otra información relacionada con las contribuciones
                realizadas dentro de Parkly, utilizada para mantener el sistema
                de participación y el perfil del usuario.
              </p>
            </li>
          </ul>
        )
      },

      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos recogidos se utilizan para proporcionar las
            funcionalidades de Parkly, incluyendo la gestión de tu cuenta y
            perfil, mostrar mapas y ubicaciones de parkings para motos, ayudarte
            a encontrar lugares cercanos, guardar tus favoritos y gestionar los
            puntos obtenidos por tus contribuciones a la comunidad.
          </p>
        )
      },

      {
        titulo: 'Uso de la ubicación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Parkly utiliza la ubicación del dispositivo únicamente cuando es
            necesaria para las funcionalidades relacionadas con el mapa y la
            búsqueda de parkings cercanos. El acceso a la ubicación depende de
            los permisos que concedas al sistema operativo. Puedes modificar o
            retirar estos permisos en cualquier momento desde los ajustes de tu
            dispositivo. Parkly no utiliza la ubicación para crear perfiles
            publicitarios ni para vender información sobre los usuarios.
          </p>
        )
      },

      {
        titulo: 'Con quién compartimos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Parkly puede utilizar servicios de terceros necesarios para
            proporcionar determinadas funcionalidades de la aplicación, como
            servicios de autenticación, almacenamiento de datos o mapas. Estos
            proveedores pueden procesar la información necesaria para prestar
            dichos servicios de acuerdo con sus propias políticas de privacidad.
            No vendemos los datos personales de los usuarios ni los compartimos
            con terceros para fines publicitarios.
          </p>
        )
      },

      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Conservamos los datos asociados a tu cuenta mientras mantengas una
            cuenta activa o mientras sean necesarios para proporcionar las
            funcionalidades de Parkly. Puedes solicitar la eliminación de tu
            cuenta y de los datos personales asociados en cualquier momento
            contactando con nosotros.
          </p>
        )
      },

      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Puedes solicitar acceso, rectificación o eliminación de tus datos
            personales, así como realizar cualquier consulta relacionada con el
            tratamiento de tus datos, escribiendo a{' '}
            <span className="font-medium text-slate-900">
              alejandro.sanjim2000@gmail.com
            </span>
            .
          </p>
        )
      },

      {
        titulo: 'Publicidad y seguimiento',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Parkly no vende datos personales ni utiliza la información de
            ubicación o del perfil para crear perfiles publicitarios. Los datos
            recogidos se utilizan para proporcionar las funcionalidades propias
            de la aplicación.
          </p>
        )
      },

      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política de privacidad ocasionalmente para
            reflejar cambios en la aplicación, en los servicios utilizados o en
            los requisitos legales aplicables. Cualquier modificación se
            reflejará en esta misma página indicando la fecha de actualización
            correspondiente.
          </p>
        )
      }
    ]
  },

pastillero: {
  nombre: 'Pastillero+',
  fechaActualizacion: '25 de septiembre de 2026',

  secciones: [
    {
      titulo: 'Datos que recogemos',
      contenido: (
        <ul className="space-y-5">
          <li className="flex gap-4">
            <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
              01
            </div>
            <p className="m-0 leading-7 text-slate-600">
              <span className="font-semibold text-slate-900">
                Datos personales.
              </span>{' '}
              Pastillero+ no requiere crear una cuenta ni iniciar sesión y no
              solicita datos personales para utilizar sus funcionalidades.
            </p>
          </li>

          <li className="flex gap-4">
            <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
              02
            </div>
            <p className="m-0 leading-7 text-slate-600">
              <span className="font-semibold text-slate-900">
                Información de medicamentos.
              </span>{' '}
              Los medicamentos, dosis, horarios y demás información que
              introduzcas en la aplicación se almacenan localmente en tu
              dispositivo.
            </p>
          </li>

          <li className="flex gap-4">
            <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
              03
            </div>
            <p className="m-0 leading-7 text-slate-600">
              <span className="font-semibold text-slate-900">
                Datos de uso de la aplicación.
              </span>{' '}
              Pastillero+ no recopila ni envía a servidores información personal
              relacionada con el uso de la aplicación.
            </p>
          </li>
        </ul>
      )
    },

    {
      titulo: 'Cómo usamos los datos',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          La información introducida en Pastillero+ se utiliza exclusivamente
          para proporcionar las funcionalidades de la aplicación, como
          organizar medicamentos, configurar dosis y horarios y mostrar
          recordatorios de las tomas programadas.
        </p>
      )
    },

    {
      titulo: 'Almacenamiento de datos',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Toda la información introducida por el usuario se almacena
          localmente en el dispositivo. Pastillero+ no utiliza servidores,
          cuentas de usuario ni servicios de almacenamiento en la nube para
          almacenar la información de los medicamentos o las dosis.
        </p>
      )
    },

    {
      titulo: 'Notificaciones',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Pastillero+ puede utilizar notificaciones locales del dispositivo
          para recordar al usuario las dosis programadas. Estas notificaciones
          se generan y gestionan localmente en el dispositivo y no requieren
          enviar los datos de las dosis a un servidor externo.
        </p>
      )
    },

    {
      titulo: 'Servicios de terceros',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Pastillero+ no utiliza servicios de terceros para recopilar,
          almacenar o procesar los datos personales o la información de
          medicamentos introducida por el usuario.
        </p>
      )
    },

    {
      titulo: 'Publicidad y seguimiento',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Pastillero+ no vende datos personales ni utiliza la información del
          usuario para crear perfiles publicitarios. La aplicación no requiere
          una cuenta y no utiliza los datos introducidos para realizar
          seguimiento del usuario.
        </p>
      )
    },

    {
      titulo: 'Conservación y eliminación',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Los datos se conservan localmente en el dispositivo mientras la
          aplicación los necesite. El usuario puede eliminar la información
          almacenada desde las propias funcionalidades de la aplicación o
          eliminando los datos de la aplicación del dispositivo.
        </p>
      )
    },

    {
      titulo: 'Tus derechos',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Como Pastillero+ no recopila ni almacena datos personales en
          servidores, no mantiene un perfil personal del usuario. Si tienes
          alguna consulta relacionada con la privacidad de la aplicación,
          puedes contactar con nosotros escribiendo a{' '}
          <span className="font-medium text-slate-900">
            alejandro.sanjim2000@gmail.com
          </span>
          .
        </p>
      )
    },

    {
      titulo: 'Cambios en esta política',
      contenido: (
        <p className="m-0 leading-7 text-slate-600">
          Podemos actualizar esta política de privacidad ocasionalmente para
          reflejar cambios en la aplicación o en los requisitos legales
          aplicables. Cualquier modificación se reflejará en esta misma página
          indicando la fecha de actualización correspondiente.
        </p>
      )
    }
  ]
},
  scanvault: {
    nombre: 'ScanVault',
fechaActualizacion: '9 de octubre de 2026',

secciones: [
  {
    titulo: 'Datos que recogemos',
    contenido: (
      <ul className="space-y-5">
        <li className="flex gap-4">
          <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
            01
          </div>

          <p className="m-0 leading-7 text-slate-600">
            <span className="font-semibold text-slate-900">
              Datos de cuenta.
            </span>{' '}
            Correo electrónico e identificadores de usuario gestionados a
            través de Firebase Authentication, necesarios para identificar
            y gestionar tu cuenta.
          </p>
        </li>

        <li className="flex gap-4">
          <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
            02
          </div>

          <p className="m-0 leading-7 text-slate-600">
            <span className="font-semibold text-slate-900">
              Documentos e imágenes escaneados.
            </span>{' '}
            Las imágenes, archivos y documentos que decidas importar,
            capturar o guardar mediante la aplicación. Si la funcionalidad
            de sincronización está habilitada, estos archivos podrán
            almacenarse en Firebase Storage y los metadatos asociados en
            Firebase Firestore.
          </p>
        </li>

        <li className="flex gap-4">
          <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
            03
          </div>

          <p className="m-0 leading-7 text-slate-600">
            <span className="font-semibold text-slate-900">
              Texto extraído de los documentos.
            </span>{' '}
            La aplicación puede utilizar reconocimiento óptico de
            caracteres (OCR) para extraer texto de las imágenes y facilitar
            la búsqueda o consulta de su contenido. El texto procesado
            dependerá de las funciones que utilices.
          </p>
        </li>

        <li className="flex gap-4">
          <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
            04
          </div>

          <p className="m-0 leading-7 text-slate-600">
            <span className="font-semibold text-slate-900">
              Datos técnicos básicos.
            </span>{' '}
            Identificadores técnicos e información necesaria para el
            funcionamiento, la seguridad y el diagnóstico de errores del
            servicio, cuando corresponda.
          </p>
        </li>
      </ul>
    )
  },

  {
    titulo: 'Cómo usamos los datos',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        Los datos se utilizan para proporcionar las funciones de ScanVault:
        gestionar tu cuenta, capturar e importar documentos, procesar
        imágenes mediante OCR, organizar y consultar archivos y, cuando
        esté disponible, sincronizar documentos entre dispositivos. No
        utilizamos el contenido de tus documentos con fines publicitarios.
      </p>
    )
  },

  {
    titulo: 'Con quién compartimos los datos',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        Utilizamos servicios de Firebase (Google) para las funciones de
        autenticación, base de datos y almacenamiento en la nube que
        correspondan. La aplicación también puede utilizar bibliotecas de
        reconocimiento de texto para procesar documentos. No vendemos tus
        datos personales ni compartimos tus documentos con terceros con
        fines publicitarios.
      </p>
    )
  },

  {
    titulo: 'Conservación y eliminación',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        Conservamos los datos de tu cuenta y los archivos almacenados en
        nuestros servicios mientras sean necesarios para prestar las
        funcionalidades solicitadas. Puedes solicitar la eliminación de
        tu cuenta y de los datos asociados contactando con nosotros. Los
        archivos guardados exclusivamente en tu dispositivo pueden
        requerir su eliminación desde la propia aplicación o desde el
        dispositivo.
      </p>
    )
  },

  {
    titulo: 'Permisos del dispositivo',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        ScanVault puede solicitar acceso a la cámara para capturar
        documentos y a las fotografías o archivos del dispositivo para
        importar documentos que selecciones. Estos permisos se utilizan
        para las funciones solicitadas por el usuario.
      </p>
    )
  },

  {
    titulo: 'Tus derechos',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        Puedes solicitar acceso, rectificación o eliminación de tus datos
        personales, así como ejercer los demás derechos reconocidos por la
        normativa aplicable, escribiendo a
        alejandro.sanjim2000@gmail.com.
      </p>
    )
  },

  {
    titulo: 'Cambios en esta política',
    contenido: (
      <p className="m-0 leading-7 text-slate-600">
        Podemos actualizar esta política ocasionalmente. Cualquier cambio
        se reflejará en esta misma página con la fecha de actualización
        correspondiente.
      </p>
    )
  }
]

},


  ludus: {
    nombre: 'Ludus',
    fechaActualizacion: '20 de octubre de 2026',

    secciones: [
      {
        titulo: 'Datos que recogemos',
        contenido: (
          <ul className="space-y-5">
            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                01
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de cuenta.
                </span>{' '}
                Correo electrónico, nombre de usuario e información básica
                del perfil necesarios para crear y gestionar tu cuenta en
                Ludus.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                02
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Contenido generado por el usuario.
                </span>{' '}
                Publicaciones, comentarios, listas de videojuegos, tier lists
                y otra información que decidas compartir en la aplicación.
                También se incluye el contenido que publiques o guardes en
                tu perfil, como tus juegos deseados, completados o abandonados.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                03
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos de interacción social.
                </span>{' '}
                Información relacionada con los usuarios a los que sigues,
                los seguidores de tu perfil, los me gusta y las interacciones
                que realices con las publicaciones de otros usuarios.
              </p>
            </li>

            <li className="flex gap-4">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-sm">
                04
              </div>
              <p className="m-0 leading-7 text-slate-600">
                <span className="font-semibold text-slate-900">
                  Datos técnicos.
                </span>{' '}
                Identificadores técnicos e información básica de uso
                necesarios para el funcionamiento, la seguridad y el
                diagnóstico de errores de la aplicación, cuando corresponda.
              </p>
            </li>
          </ul>
        )
      },

      {
        titulo: 'Cómo usamos los datos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos recogidos se utilizan para proporcionar las
            funcionalidades de Ludus, gestionar las cuentas y los perfiles,
            guardar y mostrar las colecciones de videojuegos y las tier lists,
            publicar contenido, permitir las interacciones sociales y mostrar
            las publicaciones y perfiles de otros usuarios.
          </p>
        )
      },

      {
        titulo: 'Contenido público y visibilidad',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Ludus permite compartir contenido relacionado con videojuegos
            e interactuar con otros usuarios. Las publicaciones, comentarios,
            tier lists y demás información que decidas publicar podrán ser
            visibles para otros usuarios de la aplicación, según las
            funcionalidades y opciones de visibilidad disponibles. Te
            recomendamos no compartir información personal que no quieras
            hacer pública.
          </p>
        )
      },

      {
        titulo: 'Servicios de terceros',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Ludus puede utilizar servicios de terceros para proporcionar
            funcionalidades como la autenticación, el almacenamiento de
            información y la sincronización de datos. Estos proveedores
            pueden procesar la información necesaria para prestar dichos
            servicios de acuerdo con sus propias políticas de privacidad.
          </p>
        )
      },

      {
        titulo: 'Conservación y eliminación',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Conservamos los datos asociados a tu cuenta mientras sean
            necesarios para proporcionar las funcionalidades de Ludus.
            Puedes solicitar la eliminación de tu cuenta y de los datos
            personales asociados contactando con nosotros. Determinados
            contenidos o interacciones podrían dejar de estar disponibles
            al eliminarse la cuenta o el contenido correspondiente.
          </p>
        )
      },

      {
        titulo: 'Tus derechos',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Puedes solicitar acceso, rectificación o eliminación de tus
            datos personales, así como ejercer los demás derechos reconocidos
            por la normativa aplicable, escribiendo a{' '}
            <span className="font-medium text-slate-900">
              alejandro.sanjim2000@gmail.com
            </span>.
          </p>
        )
      },

      {
        titulo: 'Publicidad y seguimiento',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Los datos de Ludus se utilizan para proporcionar las
            funcionalidades de la aplicación. El uso de datos con fines
            publicitarios o de seguimiento dependerá de los servicios
            integrados en la aplicación y de su configuración.
          </p>
        )
      },

      {
        titulo: 'Cambios en esta política',
        contenido: (
          <p className="m-0 leading-7 text-slate-600">
            Podemos actualizar esta política de privacidad para reflejar
            cambios en Ludus, en los servicios utilizados o en los requisitos
            legales aplicables. Cualquier modificación se reflejará en esta
            misma página indicando la fecha de actualización correspondiente.
          </p>
        )
      }
    ]
  },


  // Ejemplo de cómo añadir una futura app:
  //
  // otraapp: {
  //   nombre: 'OtraApp',
  //   fechaActualizacion: '...',
  //   secciones: [...],
  // },
}

export default function PrivacidadContent() {
  const searchParams = useSearchParams()

  const app = searchParams.get('app')
  const policy = app ? PRIVACY_POLICIES[app] : null

  if (!app) {
    return (
      <main className="min-h-screen  px-4 py-4">
        <div className="mx-auto max-w-2xl">
          <div className="rounded-3xl border border-slate-200 p-8 shadow-sm sm:p-12">
            <h1 className="text-3xl font-bold tracking-tight text-gray-300">
              Política de privacidad
            </h1>

            <p className="mt-4 leading-7 text-white">
              Indica la app en la URL, por ejemplo:
            </p>

            <code className="mt-4 block rounded-xl bg-slate-900 px-4 py-3 font-mono text-sm text-slate-100">
              /privacidad?app=mysyncedlist
            </code>
          </div>
        </div>
      </main>
    )
  }

  if (!policy) {
    return (
      <main className="min-h-screen  px-4 py-4">
        <div className="mx-auto max-w-2xl">
          <div className="rounded-3xl border border-slate-200 p-8 shadow-sm sm:p-12">
            <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl text-xl">
              ?
            </div>

            <h1 className="text-3xl font-bold tracking-tight text-gray-300">
              App no encontrada
            </h1>

            <p className="mt-4 leading-7 text-white">
              No hay una política de privacidad registrada para la app
              solicitada.
            </p>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen  px-4 py-4 sm:py-4">
      <div className="mx-auto max-w-3xl">
        {/* Cabecera */}
        <header className="mb-10">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 shadow-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            Documento legal
          </div>

          <h1 className="text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
            Política de privacidad
          </h1>

          <div className="mt-5 flex flex-col gap-2 text-sm text-white sm:flex-row sm:items-center sm:gap-3">
            <span className="font-medium text-white">{policy.nombre}</span>

            <span className="hidden text-slate-300 sm:block">•</span>

            <span>Última actualización: {policy.fechaActualizacion}</span>
          </div>
        </header>

        {/* Contenido */}
        <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
          {policy.secciones.map((seccion, index) => (
            <section
              key={seccion.titulo}
              className={`px-6 py-8 sm:px-10 sm:py-10 ${
                index !== 0 ? 'border-t border-slate-100' : ''
              }`}
            >
              <div className="flex gap-5">
                {/* Número de sección */}
                <div className="hidden shrink-0 pt-1 sm:block">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-xs font-semibold text-slate-500">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                </div>

                <div className="min-w-0 flex-1">
                  <h2 className="m-0 text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
                    {seccion.titulo}
                  </h2>

                  <div className="mt-5">{seccion.contenido}</div>
                </div>
              </div>
            </section>
          ))}
        </div>

        {/* Pie */}
        <footer className="mt-8 px-2 text-center">
          <p className="text-xs leading-5 text-slate-400">
            Esta política de privacidad se aplica a {policy.nombre}.
          </p>
        </footer>
      </div>
    </main>
  )
}
